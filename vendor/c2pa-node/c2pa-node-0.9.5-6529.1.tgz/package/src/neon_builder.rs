// Copyright 2025 Adobe. All rights reserved.
// This file is licensed to you under the Apache License,
// Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
// or the MIT license (http://opensource.org/licenses/MIT),
// at your option.

// Unless required by applicable law or agreed to in writing,
// this software is distributed on an "AS IS" BASIS, WITHOUT
// WARRANTIES OR REPRESENTATIONS OF ANY KIND, either express or
// implied. See the LICENSE-MIT and LICENSE-APACHE files for the
// specific language governing permissions and limitations under
// each license.

use std::io::Cursor;
use std::ops::Deref;
use std::sync::Arc;

use c2pa::{
    assertions::{Action, Actions},
    Builder, BuilderIntent, Ingredient, Reader,
};
use neon::context::Context as NeonContext;
use neon::prelude::*;
use neon_serde4;
use serde_json;
use tokio::sync::Mutex;

use crate::asset::parse_asset;
use crate::error::{as_js_error, Error};
use crate::neon_identity_assertion_signer::NeonIdentityAssertionSigner;
use crate::neon_reader::NeonReader;
use crate::neon_signer::{CallbackSignerConfig, NeonCallbackSigner, NeonLocalSigner};
use crate::runtime::runtime;
use crate::utils::parse_settings;

pub struct NeonBuilder {
    builder: Arc<Mutex<Builder>>,
}

impl NeonBuilder {
    pub fn new(mut cx: FunctionContext) -> JsResult<JsBox<Self>> {
        // Parse optional settings parameter (argument 0)
        let context_opt =
            parse_settings(&mut cx, 0, "Builder").or_else(|err| cx.throw_error(err.to_string()))?;

        let builder = if let Some(context) = context_opt {
            Builder::from_context(context)
        } else {
            Builder::default()
        };

        Ok(cx.boxed(Self {
            builder: Arc::new(Mutex::new(builder)),
        }))
    }

    pub fn with_json(mut cx: FunctionContext) -> JsResult<JsBox<Self>> {
        let json = cx.argument::<JsString>(0)?.value(&mut cx);

        // Parse optional settings parameter (argument 1)
        let context_opt =
            parse_settings(&mut cx, 1, "Builder").or_else(|err| cx.throw_error(err.to_string()))?;

        let builder = if let Some(context) = context_opt {
            Builder::from_context(context)
                .with_definition(json.as_str())
                .or_else(|err| cx.throw_error(err.to_string()))?
        } else {
            Builder::default()
                .with_definition(&json)
                .or_else(|err| cx.throw_error(err.to_string()))?
        };

        Ok(cx.boxed(Self {
            builder: Arc::new(Mutex::new(builder)),
        }))
    }

    pub fn set_intent(mut cx: FunctionContext) -> JsResult<JsUndefined> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let intent_str = cx.argument::<JsString>(0)?.value(&mut cx);
        let intent: BuilderIntent = serde_json::from_str(&intent_str)
            .or_else(|_| cx.throw_error(format!("Invalid intent: {intent_str}")))?;
        let mut builder = rt.block_on(async { this.builder.lock().await });
        builder.set_intent(intent);
        Ok(cx.undefined())
    }

    pub fn set_no_embed(mut cx: FunctionContext) -> JsResult<JsUndefined> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let no_embed = cx.argument::<JsBoolean>(0)?.value(&mut cx);
        let mut builder = rt.block_on(async { this.builder.lock().await });
        builder.no_embed = no_embed;
        Ok(cx.undefined())
    }

    pub fn set_remote_url(mut cx: FunctionContext) -> JsResult<JsUndefined> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let remote_url: String = cx.argument::<JsString>(0)?.value(&mut cx);
        let mut builder = rt.block_on(async { this.builder.lock().await });
        builder.set_remote_url(&remote_url);
        Ok(cx.undefined())
    }

    pub fn add_action(mut cx: FunctionContext) -> JsResult<JsUndefined> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let action_json = cx.argument::<JsString>(0)?.value(&mut cx);
        let action: c2pa::assertions::Action =
            serde_json::from_str(&action_json).or_else(|err| cx.throw_error(err.to_string()))?;
        let mut builder = rt.block_on(async { this.builder.lock().await });
        builder
            .add_action(action)
            .or_else(|err| cx.throw_error(err.to_string()))?;
        Ok(cx.undefined())
    }

    pub fn add_assertion(mut cx: FunctionContext) -> JsResult<JsUndefined> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let label = cx.argument::<JsString>(0)?.value(&mut cx);
        let assertion_kind = cx.argument_opt(2).and_then(|js_value| {
            js_value
                .downcast::<JsString, _>(&mut cx)
                .ok()
                .map(|js_string| js_string.value(&mut cx))
        });

        let mut builder = rt.block_on(async { this.builder.lock().await });

        if let Some("Json") = assertion_kind.as_deref() {
            // For Json, expect the assertion as a string (JSON) and parse it
            let assertion_str = cx.argument::<JsString>(1)?.value(&mut cx);
            let assertion: serde_json::Value = serde_json::from_str(&assertion_str)
                .or_else(|err| cx.throw_error(format!("Invalid JSON: {err}")))?;
            builder
                .add_assertion(&label, &assertion)
                .or_else(|err| cx.throw_error(err.to_string()))?;
        } else {
            // For Cbor/Binary/Uri, expect the assertion as an object and serialize to CBOR
            let assertion_obj = cx.argument::<JsValue>(1)?;
            let assertion: serde_json::Value = neon_serde4::from_value(&mut cx, assertion_obj)
                .or_else(|err| cx.throw_error(err.to_string()))?;
            builder
                .add_assertion(&label, &assertion)
                .or_else(|err| cx.throw_error(err.to_string()))?;
        };

        Ok(cx.undefined())
    }

    pub fn add_resource(mut cx: FunctionContext) -> JsResult<JsPromise> {
        let this = cx.this::<JsBox<Self>>()?;
        let uri = cx.argument::<JsString>(0)?.value(&mut cx);
        let resource = cx
            .argument::<JsObject>(1)
            .and_then(|obj| parse_asset(&mut cx, obj))?;
        let builder = Arc::clone(&this.builder);

        let promise = cx
            .task(move || {
                // Block on acquiring the async mutex lock
                let rt = runtime();
                let mut builder = rt.block_on(async { builder.lock().await });

                resource.into_read_stream().and_then(|mut resource_stream| {
                    builder.add_resource(&uri, &mut resource_stream)?;
                    Ok(())
                })
            })
            .promise(move |mut cx, result: Result<(), Error>| match result {
                Ok(_) => Ok(cx.undefined()),
                Err(err) => as_js_error(&mut cx, err).and_then(|err| cx.throw(err)),
            });

        Ok(promise)
    }

    pub fn add_redaction(mut cx: FunctionContext) -> JsResult<JsUndefined> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let uri = cx.argument::<JsString>(0)?.value(&mut cx);
        let reason = cx.argument::<JsString>(1)?.value(&mut cx);
        let mut builder = rt.block_on(async { this.builder.lock().await });
        builder
            .definition
            .redactions
            .get_or_insert_with(Vec::new)
            .push(uri.clone());
        let action = Action::new("c2pa.redacted")
            .set_reason(reason)
            .set_parameter("redacted".to_owned(), uri)
            .or_else(|err| cx.throw_error(err.to_string()))?;
        builder
            .add_action(action)
            .or_else(|err| cx.throw_error(err.to_string()))?;
        Ok(cx.undefined())
    }

    pub fn add_ingredient(mut cx: FunctionContext) -> JsResult<JsUndefined> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let ingredient_json = cx.argument::<JsString>(0)?.value(&mut cx);
        let ingredient = Ingredient::from_json(&ingredient_json)
            .or_else(|err| cx.throw_error(err.to_string()))?;

        let mut builder = rt.block_on(async { this.builder.lock().await });
        builder.add_ingredient(ingredient);
        Ok(cx.undefined())
    }

    pub fn add_ingredient_from_asset(mut cx: FunctionContext) -> JsResult<JsPromise> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let ingredient_json = cx.argument::<JsString>(0)?.value(&mut cx);
        let ingredient = cx
            .argument::<JsObject>(1)
            .and_then(|obj| parse_asset(&mut cx, obj))?;

        let builder = Arc::clone(&this.builder);

        let channel = cx.channel();
        let (deferred, promise) = cx.promise();

        rt.spawn(async move {
            let mut builder = builder.lock().await;

            let result = async {
                let format = ingredient
                    .mime_type()
                    .ok_or_else(|| {
                        Error::Signing("Ingredient asset must have a mime type".to_string())
                    })?
                    .to_owned();
                let mut ingredient_stream = ingredient.into_read_stream()?;
                builder
                    .add_ingredient_from_stream_async(
                        &ingredient_json,
                        &format,
                        &mut ingredient_stream,
                    )
                    .await?;
                Ok(())
            }
            .await;

            deferred.settle_with(&channel, move |mut cx| match result {
                Ok(_) => Ok(cx.undefined()),
                Err(err) => as_js_error(&mut cx, err).and_then(|err| cx.throw(err)),
            });
        });

        Ok(promise)
    }

    pub fn add_ingredient_from_reader(mut cx: FunctionContext) -> JsResult<JsString> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let reader = cx.argument::<JsBox<NeonReader>>(0)?.reader();

        let mut builder = rt.block_on(async { this.builder.lock().await });
        let reader = rt.block_on(async { reader.lock().await });
        let ingredient = builder
            .add_ingredient_from_reader(&reader)
            .or_else(|err| cx.throw_error(err.to_string()))?;
        let json =
            serde_json::to_string(&ingredient).or_else(|err| cx.throw_error(err.to_string()))?;
        Ok(cx.string(json))
    }

    pub fn to_archive(mut cx: FunctionContext) -> JsResult<JsPromise> {
        let this = cx.this::<JsBox<Self>>()?;
        let dest_obj = cx.argument::<JsObject>(0)?;
        let dest = parse_asset(&mut cx, dest_obj)?;
        let is_buffer = dest.name() == "destination_buffer";
        let builder = Arc::clone(&this.builder);
        let dest_obj_root: Arc<Root<JsObject>> = Arc::new(Root::new(&mut cx, &dest_obj));

        let promise = cx
            .task(move || {
                // Block on acquiring the async mutex lock
                // Settings are automatically applied when runtime() is called
                let rt = runtime();
                let builder = rt.block_on(async { builder.lock().await });

                dest.write_stream().and_then(|mut dest_stream| {
                    builder.to_archive(&mut dest_stream)?;
                    if is_buffer {
                        let mut archive_data = Vec::new();
                        dest_stream
                            .rewind()
                            .map_err(|e| Error::Asset(format!("Failed to rewind stream: {e}")))?;
                        dest_stream
                            .read_to_end(&mut archive_data)
                            .map_err(|e| Error::Asset(format!("Failed to read stream: {e}")))?;
                        Ok(Some(archive_data))
                    } else {
                        Ok(None)
                    }
                })
            })
            .promise(move |mut cx, result: Result<Option<Vec<u8>>, Error>| {
                match result {
                    Ok(Some(archive_data)) => {
                        // If the output is a buffer, populate it with the archive data
                        let buffer = JsBuffer::from_slice(&mut cx, &archive_data)?;
                        let dest_obj = dest_obj_root.to_inner(&mut cx);
                        dest_obj.set(&mut cx, "buffer", buffer)?;
                        Ok(cx.undefined())
                    }
                    Ok(None) => Ok(cx.undefined()),
                    Err(err) => as_js_error(&mut cx, err).and_then(|err| cx.throw(err)),
                }
            });
        Ok(promise)
    }

    pub fn from_archive(mut cx: FunctionContext) -> JsResult<JsPromise> {
        let source = cx
            .argument::<JsObject>(0)
            .and_then(|obj| parse_asset(&mut cx, obj))?;

        let context_opt =
            parse_settings(&mut cx, 1, "Builder").or_else(|err| cx.throw_error(err.to_string()))?;

        let promise = cx
            .task(move || {
                let source_stream = source.into_read_stream()?;
                let builder = if let Some(context) = context_opt {
                    Builder::from_context(context).with_archive(source_stream)?
                } else {
                    Builder::default().with_archive(source_stream)?
                };
                Ok(builder)
            })
            .promise(
                move |mut cx, result: crate::error::Result<Builder>| match result {
                    Ok(builder) => Ok(cx.boxed(Self {
                        builder: Arc::new(Mutex::new(builder)),
                    })),
                    Err(err) => as_js_error(&mut cx, err).and_then(|err| cx.throw(err)),
                },
            );
        Ok(promise)
    }

    pub fn sign(mut cx: FunctionContext) -> JsResult<JsBuffer> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let signer = cx.argument::<JsBox<NeonLocalSigner>>(0)?;
        let input = cx
            .argument::<JsObject>(1)
            .and_then(|obj| parse_asset(&mut cx, obj))?;
        let output_obj = cx.argument::<JsObject>(2)?;
        let output = parse_asset(&mut cx, output_obj)?;
        let mut builder = rt.block_on(async { this.builder.lock().await });
        let signer = signer.signer();
        let format = match input.mime_type() {
            Some(mime_type) => mime_type.to_owned(),
            None => return cx.throw_error("Input asset must have a mime type"),
        };
        let mut input_stream = input
            .into_read_stream()
            .or_else(|err| cx.throw_error(err.to_string()))?;
        let mut output_stream = output
            .write_stream()
            .or_else(|err| cx.throw_error(err.to_string()))?;
        let bytes = builder
            .sign(&**signer, &format, &mut input_stream, &mut output_stream)
            .or_else(|err| cx.throw_error(err.to_string()))?;

        // If the output is a buffer, write the signed asset to it
        // Create a new JsBuffer with the contents of output_stream
        if output.name() == "destination_buffer" {
            let mut signed_asset = Vec::new();
            output_stream
                .rewind()
                .or_else(|e| cx.throw_error(format!("Failed to rewind stream: {e}")))?;
            output_stream
                .read_to_end(&mut signed_asset)
                .or_else(|e| cx.throw_error(format!("Failed to read stream: {e}")))?;
            let buffer = JsBuffer::from_slice(&mut cx, &signed_asset)?;
            // Set the new JsBuffer on the output JsObject
            output_obj.set(&mut cx, "buffer", buffer)?;
        }

        let buffer = JsBuffer::from_slice(&mut cx, bytes.as_slice())?;
        Ok(buffer)
    }

    // TODO: This mimics the previous c2pa-node iteration's arguments.
    // It is probably redundant with sign_async.
    pub fn sign_config_async(mut cx: FunctionContext) -> JsResult<JsPromise> {
        let rt = runtime();
        let channel = cx.channel();

        let this = cx.this::<JsBox<Self>>()?;
        let callback = cx.argument::<JsFunction>(0)?;
        let rooted_callback: Arc<Root<JsFunction>> = Arc::new(Root::new(&mut cx, &callback));
        let js_config = cx.argument::<JsObject>(1)?;
        let config = CallbackSignerConfig::from_js_config(&mut cx, js_config)?;
        let signer = NeonCallbackSigner::new(cx.channel(), rooted_callback, (**config).clone());

        let input = cx
            .argument::<JsObject>(2)
            .and_then(|obj| parse_asset(&mut cx, obj))?;
        let output_obj = cx.argument::<JsObject>(3)?;
        let output = parse_asset(&mut cx, output_obj)?;
        let format = match input.mime_type() {
            Some(mime_type) => mime_type.to_owned(),
            None => return cx.throw_error("Input asset must have a mime type"),
        };
        let mut input_stream = input
            .into_read_stream()
            .or_else(|err| cx.throw_error(err.to_string()))?;
        let mut output_stream = output
            .write_stream()
            .or_else(|err| cx.throw_error(err.to_string()))?;

        let builder = Arc::clone(&this.builder);
        let (deferred, promise) = cx.promise();
        rt.spawn(async move {
            let result = builder
                .lock()
                .await
                .sign_async(&signer, &format, &mut input_stream, &mut output_stream)
                .await
                .map(|sign_result| (sign_result, output_stream));

            deferred.settle_with(&channel, move |mut cx| match result {
                Ok((signed_bytes, mut output_stream)) => {
                    let signed_asset = if output.name() == "destination_buffer" {
                        let mut buffer = Vec::new();
                        match output_stream.rewind() {
                            Ok(_) => (),
                            Err(e) => {
                                return cx.throw_error(format!("Failed to rewind stream: {e}"))
                            }
                        }
                        match output_stream.read_to_end(&mut buffer) {
                            Ok(_) => (),
                            Err(e) => return cx.throw_error(format!("Failed to read stream: {e}")),
                        }
                        Some(buffer)
                    } else {
                        None
                    };

                    let result_buffer = JsBuffer::from_slice(&mut cx, signed_bytes.as_slice())?;

                    if let Some(signed_asset) = signed_asset {
                        let signed_buffer = JsBuffer::from_slice(&mut cx, &signed_asset)?;
                        let result = cx.empty_object();
                        result.set(&mut cx, "manifest", result_buffer)?;
                        result.set(&mut cx, "signedAsset", signed_buffer)?;
                        Ok(result.upcast::<JsValue>())
                    } else {
                        Ok(result_buffer.upcast::<JsValue>())
                    }
                }
                Err(err) => cx.throw_error(err.to_string()),
            });
        });
        Ok(promise)
    }

    pub fn sign_async(mut cx: FunctionContext) -> JsResult<JsPromise> {
        let rt = runtime();
        let channel = cx.channel();

        let this = cx.this::<JsBox<Self>>()?;
        let signer = cx.argument::<JsBox<NeonCallbackSigner>>(0)?;
        let signer_ref: &NeonCallbackSigner = signer.deref();
        let signer = signer_ref.clone();
        let input = cx
            .argument::<JsObject>(1)
            .and_then(|obj| parse_asset(&mut cx, obj))?;
        let output_obj = cx.argument::<JsObject>(2)?;
        let output = parse_asset(&mut cx, output_obj)?;
        let format = match input.mime_type() {
            Some(mime_type) => mime_type.to_owned(),
            None => return cx.throw_error("Input asset must have a mime type"),
        };
        let mut input_stream = input
            .into_read_stream()
            .or_else(|err| cx.throw_error(err.to_string()))?;
        let mut output_stream = output
            .write_stream()
            .or_else(|err| cx.throw_error(err.to_string()))?;

        let builder = Arc::clone(&this.builder);
        let (deferred, promise) = cx.promise();
        rt.spawn(async move {
            let result = builder
                .lock()
                .await
                .sign_async(&signer, &format, &mut input_stream, &mut output_stream)
                .await
                .map(|sign_result| (sign_result, output_stream));

            deferred.settle_with(&channel, move |mut cx| match result {
                Ok((signed_bytes, mut output_stream)) => {
                    let signed_asset = if output.name() == "destination_buffer" {
                        let mut buffer = Vec::new();
                        match output_stream.rewind() {
                            Ok(_) => (),
                            Err(e) => {
                                return cx.throw_error(format!("Failed to rewind stream: {e}"))
                            }
                        }
                        match output_stream.read_to_end(&mut buffer) {
                            Ok(_) => (),
                            Err(e) => return cx.throw_error(format!("Failed to read stream: {e}")),
                        }
                        Some(buffer)
                    } else {
                        None
                    };

                    let result_buffer = JsBuffer::from_slice(&mut cx, signed_bytes.as_slice())?;

                    if let Some(signed_asset) = signed_asset {
                        let signed_buffer = JsBuffer::from_slice(&mut cx, &signed_asset)?;
                        let result = cx.empty_object();
                        result.set(&mut cx, "manifest", result_buffer)?;
                        result.set(&mut cx, "signedAsset", signed_buffer)?;
                        Ok(result.upcast::<JsValue>())
                    } else {
                        Ok(result_buffer.upcast::<JsValue>())
                    }
                }
                Err(err) => cx.throw_error(err.to_string()),
            });
        });
        Ok(promise)
    }

    pub fn identity_sign_async(mut cx: FunctionContext) -> JsResult<JsPromise> {
        let rt = runtime();
        let channel = cx.channel();

        let this = cx.this::<JsBox<Self>>()?;
        let signer = cx.argument::<JsBox<NeonIdentityAssertionSigner>>(0)?;
        let signer_ref: &NeonIdentityAssertionSigner = signer.deref();
        let signer = signer_ref.clone();
        let input = cx
            .argument::<JsObject>(1)
            .and_then(|obj| parse_asset(&mut cx, obj))?;
        let output_obj = cx.argument::<JsObject>(2)?;
        let output = parse_asset(&mut cx, output_obj)?;
        let format = match input.mime_type() {
            Some(mime_type) => mime_type.to_owned(),
            None => return cx.throw_error("Input asset must have a mime type"),
        };
        let mut input_stream = input
            .into_read_stream()
            .or_else(|err| cx.throw_error(err.to_string()))?;
        let mut output_stream = output
            .write_stream()
            .or_else(|err| cx.throw_error(err.to_string()))?;

        let builder = Arc::clone(&this.builder);
        let (deferred, promise) = cx.promise();

        rt.spawn(async move {
            let result = builder
                .lock()
                .await
                .sign_async(&signer, &format, &mut input_stream, &mut output_stream)
                .await
                .map(|sign_result| (sign_result, output_stream));

            deferred.settle_with(&channel, move |mut cx| match result {
                Ok((signed_bytes, mut output_stream)) => {
                    let signed_asset = if output.name() == "destination_buffer" {
                        let mut buffer = Vec::new();
                        match output_stream.rewind() {
                            Ok(_) => (),
                            Err(e) => {
                                return cx.throw_error(format!("Failed to rewind stream: {e}"))
                            }
                        }
                        match output_stream.read_to_end(&mut buffer) {
                            Ok(_) => (),
                            Err(e) => return cx.throw_error(format!("Failed to read stream: {e}")),
                        }
                        Some(buffer)
                    } else {
                        None
                    };

                    let result_buffer = JsBuffer::from_slice(&mut cx, signed_bytes.as_slice())?;

                    if let Some(signed_asset) = signed_asset {
                        let signed_buffer = JsBuffer::from_slice(&mut cx, &signed_asset)?;
                        let result = cx.empty_object();
                        result.set(&mut cx, "manifest", result_buffer)?;
                        result.set(&mut cx, "signedAsset", signed_buffer)?;
                        Ok(result.upcast::<JsValue>())
                    } else {
                        Ok(result_buffer.upcast::<JsValue>())
                    }
                }
                Err(err) => cx.throw_error(err.to_string()),
            });
        });
        Ok(promise)
    }

    pub fn manifest_definition(mut cx: FunctionContext) -> JsResult<JsValue> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let builder = rt.block_on(async { this.builder.lock().await });
        let json = serde_json::to_string(&builder.definition)
            .or_else(|err| cx.throw_error(err.to_string()))?;
        Ok(cx.string(json).upcast())
    }

    /// Retains only the actions for which the JS `keep` predicate returns true. The inception
    /// action, `c2pa.created` or `c2pa.opened`, is always kept, per `Builder::filter_actions`.
    ///
    /// If `keep` throws or returns a non-boolean, the exception is surfaced to the caller. Because
    /// the underlying filter mutates in place, the builder may be left partially filtered when the
    /// predicate throws midway; callers should discard it on error.
    ///
    /// # Deadlock
    /// The builder's lock is held for the entire call, so the `keep` predicate must not call back
    /// into the same builder, for example `getManifestDefinition` or another filter: the lock is not
    /// re-entrant and re-entry would deadlock. The predicate should only inspect the `action`
    /// argument it is given.
    pub fn filter_actions(mut cx: FunctionContext) -> JsResult<JsUndefined> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let keep = cx.argument::<JsFunction>(0)?;
        let undefined = cx.undefined();
        let mut builder = rt.block_on(async { this.builder.lock().await });

        // The c2pa filter closure is `FnMut(&Action) -> bool` with no error channel, so capture a
        // JS exception out-of-band and re-raise it after filtering. Once a throw is pending we
        // stop invoking JS entirely, since calling more JS APIs with an exception pending is unsound.
        // This means the predicate is not run for the remaining actions, which is intentional: we
        // abort and re-raise, and the caller must discard the partially mutated builder anyway,
        // so their side effects would not be observable regardless.
        let mut pending: Option<neon::result::Throw> = None;
        let filter_result = builder
            .filter_actions(|action| {
                if pending.is_some() {
                    return false;
                }
                let js_action = match neon_serde4::to_value(&mut cx, action) {
                    Ok(v) => v,
                    Err(e) => {
                        pending = cx.throw_error::<_, ()>(e.to_string()).err();
                        return false;
                    }
                };
                match callback_returns_true(&mut cx, &keep, undefined, js_action) {
                    Ok(keep) => keep,
                    Err(throw) => {
                        pending = Some(throw);
                        false
                    }
                }
            })
            .map(|_| ());

        // A pending JS exception is the root cause and takes precedence over any Rust-side error.
        if let Some(throw) = pending {
            return Err(throw);
        }
        filter_result.or_else(|err| cx.throw_error(err.to_string()))?;
        Ok(cx.undefined())
    }

    /// Replaces the actions in the `c2pa.actions`/`c2pa.actions.v2` assertions.
    /// `softwareAgents`/`allActionsIncluded`/`templates`/`metadata` are preserved as-is.
    ///
    /// A manifest can carry more than one actions assertion (the created-list and gathered-list
    /// entries are distinct assertions). `transform` is invoked once per actions assertion,
    /// in positional order, with that assertion's own actions. It return value
    /// replaces only that assertion's actions.
    /// No-op if there is no actions assertion. Use `add_action` for those.
    ///
    /// If `transform` throws or its return value doesn't deserialize into an action list, the
    /// exception is surfaced to the caller and the builder is left unchanged. The same applies
    /// when an existing actions assertion is present but malformed. All fallible work runs
    /// before any mutation, so a failure never leaves a partially-rewritten builder.
    ///
    /// An assertion whose `transform` returns an empty list is dropped rather than written as an
    /// invalid empty actions array, matching `filter_actions`.
    ///
    /// The returned list is written back verbatim: it is not validated or reordered, and unlike
    /// [`Self::filter_actions`] the inception action is not force-kept. A `transform` that drops
    /// `c2pa.created`/`c2pa.opened` or moves it out of first position can produce an actions
    /// array that fails validation at signing time.
    ///
    /// # Deadlock
    /// The builder's lock is held for the whole call, so `transform` must not call back into the
    /// same builder, for example `getManifestDefinition` or a filter: the lock is not re-entrant
    /// and re-entry would deadlock.
    pub fn update_actions(mut cx: FunctionContext) -> JsResult<JsUndefined> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let transform = cx.argument::<JsFunction>(0)?;
        let mut builder = rt.block_on(async { this.builder.lock().await });

        // Every actions assertion, in positional order.
        let positions: Vec<usize> = builder
            .definition
            .assertions
            .iter()
            .enumerate()
            .filter(|(_, a)| a.label.starts_with(Actions::LABEL))
            .map(|(i, _)| i)
            .collect();

        // Decode every assertion up front.
        // The roundtrip is so we can access what we need to without the direct type access.
        let mut decoded: Vec<(usize, Actions)> = Vec::with_capacity(positions.len());
        for pos in positions {
            let value = serde_json::to_value(&builder.definition.assertions[pos].data)
                .or_else(|err| cx.throw_error(err.to_string()))?;
            let actions: Actions =
                serde_json::from_value(value).or_else(|err| cx.throw_error(err.to_string()))?;
            decoded.push((pos, actions));
        }

        // Run the transform for every assertion before mutating anything...
        let mut rewritten: Vec<(usize, Option<serde_json::Value>)> =
            Vec::with_capacity(decoded.len());
        for (pos, mut actions) in decoded {
            let js_actions = neon_serde4::to_value(&mut cx, &actions.actions)
                .or_else(|err| cx.throw_error(err.to_string()))?;
            let undefined = cx.undefined();
            let result = transform.call(&mut cx, undefined, [js_actions])?;
            let updated_actions: Vec<Action> = neon_serde4::from_value(&mut cx, result)
                .or_else(|err| cx.throw_error(err.to_string()))?;

            if updated_actions.is_empty() {
                rewritten.push((pos, None));
                continue;
            }
            actions.actions = updated_actions;
            let value =
                serde_json::to_value(&actions).or_else(|err| cx.throw_error(err.to_string()))?;
            rewritten.push((pos, Some(value)));
        }

        // Mutate in place.
        let mut emptied: Vec<usize> = Vec::new();
        for (pos, value) in rewritten {
            match value {
                Some(value) => {
                    let data = serde_json::from_value(value)
                        .or_else(|err| cx.throw_error(err.to_string()))?;
                    builder.definition.assertions[pos].data = data;
                }
                None => emptied.push(pos),
            }
        }
        // Remove emptied assertions from the back so earlier indices stay valid.
        for pos in emptied.into_iter().rev() {
            builder.definition.assertions.remove(pos);
        }

        Ok(cx.undefined())
    }

    /// Retains ingredients, rescuing an otherwise-orphaned ingredient when the JS `rescue`
    /// predicate returns true for it. Referenced and `parentOf` ingredients are always kept,
    /// per `Builder::filter_ingredients`.
    ///
    /// The `rescue` predicate is called with two arguments: the ingredient, and its parsed
    /// provenance as a manifest store, `ManifestStore`, derived from the ingredient's embedded
    /// `manifest_data`, or `null` when the ingredient has no embedded manifest. This lets the
    /// predicate make provenance-aware decisions, for example "the ingredient's chain contains AI",
    /// without the caller having to re-read the whole builder first.
    ///
    /// If `rescue` throws or returns a non-boolean, the exception is surfaced to the caller. As
    /// with [`Self::filter_actions`], the builder may be left partially filtered when the
    /// predicate throws midway; callers should discard it on error.
    ///
    /// # Deadlock
    /// As with [`Self::filter_actions`], the builder's lock is held for the whole call, so `rescue`
    /// must not call back into the same builder; doing so would deadlock. It should only inspect
    /// the `ingredient` and `provenance` arguments it is given.
    pub fn filter_ingredients(mut cx: FunctionContext) -> JsResult<JsUndefined> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let rescue = cx.argument::<JsFunction>(0)?;
        let undefined = cx.undefined();
        let mut builder = rt.block_on(async { this.builder.lock().await });

        // See `filter_actions`: capture a JS exception out-of-band and re-raise it afterwards,
        // short-circuiting once a throw is pending.
        let mut pending: Option<neon::result::Throw> = None;
        let filter_result = builder
            .filter_ingredients(|ingredient| {
                if pending.is_some() {
                    return false;
                }
                let js_ingredient = match neon_serde4::to_value(&mut cx, ingredient) {
                    Ok(v) => v,
                    Err(e) => {
                        pending = cx.throw_error::<_, ()>(e.to_string()).err();
                        return false;
                    }
                };
                let js_provenance = ingredient_provenance_value(&mut cx, ingredient);
                match callback_returns_true_with(
                    &mut cx,
                    &rescue,
                    undefined,
                    &[js_ingredient, js_provenance],
                ) {
                    Ok(rescue) => rescue,
                    Err(throw) => {
                        pending = Some(throw);
                        false
                    }
                }
            })
            .map(|_| ());

        if let Some(throw) = pending {
            return Err(throw);
        }
        filter_result.or_else(|err| cx.throw_error(err.to_string()))?;
        Ok(cx.undefined())
    }

    /// Retains actions and ingredients together in one step, per
    /// `Builder::filter_actions_and_ingredients`.
    ///
    /// `rescue_ingredient` is evaluated for every ingredient first; any action referencing an
    /// ingredient it would rescue is force-kept regardless of `keep_action`.
    ///
    /// If either predicate throws or returns a non-boolean, the exception is surfaced to the
    /// caller. As with [`Self::filter_actions`], the builder may be left partially filtered when a
    /// predicate throws midway; callers should discard it on error.
    ///
    /// # Deadlock
    /// As with [`Self::filter_actions`], the builder's lock is held for the whole call, so neither
    /// predicate must call back into the same builder; doing so would deadlock.
    pub fn filter_actions_and_ingredients(cx: FunctionContext) -> JsResult<JsUndefined> {
        let rt = runtime();
        // `cx` and `pending` are each borrowed mutably from one closure at a time, never by both
        // closures simultaneously (calls into `filter_actions_and_ingredients` are synchronous and
        // sequential), so `RefCell` lets both `FnMut` closures below share access without a
        // conflicting double mutable borrow of `cx`/`pending` themselves.
        let cx_cell = std::cell::RefCell::new(cx);
        let pending: std::cell::RefCell<Option<neon::result::Throw>> =
            std::cell::RefCell::new(None);

        let (this, keep_action, rescue_ingredient, undefined) = {
            let mut cx = cx_cell.borrow_mut();
            let this = cx.this::<JsBox<Self>>()?;
            let keep_action = cx.argument::<JsFunction>(0)?;
            let rescue_ingredient = cx.argument::<JsFunction>(1)?;
            let undefined = cx.undefined();
            (this, keep_action, rescue_ingredient, undefined)
        };
        let mut builder = rt.block_on(async { this.builder.lock().await });

        // See `filter_actions`/`filter_ingredients`: capture a JS exception out-of-band and
        // re-raise it afterwards, short-circuiting once a throw is pending.
        let filter_result = builder
            .filter_actions_and_ingredients(
                |action| {
                    if pending.borrow().is_some() {
                        return false;
                    }
                    let mut cx = cx_cell.borrow_mut();
                    let js_action = match neon_serde4::to_value(&mut *cx, action) {
                        Ok(v) => v,
                        Err(e) => {
                            *pending.borrow_mut() = cx.throw_error::<_, ()>(e.to_string()).err();
                            return false;
                        }
                    };
                    match callback_returns_true(&mut cx, &keep_action, undefined, js_action) {
                        Ok(keep) => keep,
                        Err(throw) => {
                            *pending.borrow_mut() = Some(throw);
                            false
                        }
                    }
                },
                |ingredient| {
                    if pending.borrow().is_some() {
                        return false;
                    }
                    let mut cx = cx_cell.borrow_mut();
                    let js_ingredient = match neon_serde4::to_value(&mut *cx, ingredient) {
                        Ok(v) => v,
                        Err(e) => {
                            *pending.borrow_mut() = cx.throw_error::<_, ()>(e.to_string()).err();
                            return false;
                        }
                    };
                    let js_provenance = ingredient_provenance_value(&mut cx, ingredient);
                    match callback_returns_true_with(
                        &mut cx,
                        &rescue_ingredient,
                        undefined,
                        &[js_ingredient, js_provenance],
                    ) {
                        Ok(rescue) => rescue,
                        Err(throw) => {
                            *pending.borrow_mut() = Some(throw);
                            false
                        }
                    }
                },
            )
            .map(|_| ());

        let mut cx = cx_cell.into_inner();
        if let Some(throw) = pending.into_inner() {
            return Err(throw);
        }
        filter_result.or_else(|err| cx.throw_error(err.to_string()))?;
        Ok(cx.undefined())
    }

    /// Update a manifest property. Available properties are limited to strings and numbers.
    /// There are other methods for thumbnails, ingredients and assertions, etc.
    pub fn update_manifest_property(mut cx: FunctionContext) -> JsResult<JsUndefined> {
        let rt = runtime();
        let this = cx.this::<JsBox<Self>>()?;
        let property = cx.argument::<JsString>(0)?.value(&mut cx);
        let value = cx.argument::<JsValue>(1)?;

        let mut builder = rt.block_on(async { this.builder.lock().await });

        match property.as_str() {
            "vendor" => {
                let value = value
                    .downcast_or_throw::<JsString, _>(&mut cx)?
                    .value(&mut cx);
                builder.definition.vendor = Some(value);
            }
            "title" => {
                let value = value
                    .downcast_or_throw::<JsString, _>(&mut cx)?
                    .value(&mut cx);
                builder.definition.title = Some(value);
            }
            "format" => {
                let value = value
                    .downcast_or_throw::<JsString, _>(&mut cx)?
                    .value(&mut cx);
                builder.definition.format = value;
            }
            "instance_id" => {
                let value = value
                    .downcast_or_throw::<JsString, _>(&mut cx)?
                    .value(&mut cx);
                builder.definition.instance_id = value;
            }
            "label" => {
                let value = value
                    .downcast_or_throw::<JsString, _>(&mut cx)?
                    .value(&mut cx);
                builder.definition.label = Some(value);
            }
            "claim_version" => {
                let value = value
                    .downcast_or_throw::<JsNumber, _>(&mut cx)?
                    .value(&mut cx) as u8;
                builder.definition.claim_version = Some(value);
            }
            _ => {
                return cx.throw_error(format!(
                    "Property '{property}' not found or not a valid type"
                ))
            }
        }

        Ok(cx.undefined())
    }
}

impl Finalize for NeonBuilder {}

/// Synchronously calls a JS predicate with a single argument and returns its boolean result.
/// Propagates the pending JS exception if the predicate throws, and raises a `TypeError` if it
/// returns a non-boolean value.
fn callback_returns_true(
    cx: &mut FunctionContext,
    callback: &Handle<JsFunction>,
    this: Handle<JsUndefined>,
    arg: Handle<JsValue>,
) -> NeonResult<bool> {
    callback_returns_true_with(cx, callback, this, &[arg])
}

/// Like [`callback_returns_true`] but forwards multiple arguments to the JS predicate.
fn callback_returns_true_with(
    cx: &mut FunctionContext,
    callback: &Handle<JsFunction>,
    this: Handle<JsUndefined>,
    args: &[Handle<JsValue>],
) -> NeonResult<bool> {
    let result = callback.call(cx, this, args)?;
    let boolean = result
        .downcast::<JsBoolean, _>(cx)
        .or_else(|_| cx.throw_error("filter predicate must return a boolean"))?;
    Ok(boolean.value(cx))
}

/// Parses an ingredient's embedded `manifest_data` into a manifest-store JSON value for the JS
/// predicate. Returns `null` when the ingredient has no embedded manifest or it cannot be parsed.
fn ingredient_provenance_value<'a>(
    cx: &mut FunctionContext<'a>,
    ingredient: &Ingredient,
) -> Handle<'a, JsValue> {
    let null = cx.null().upcast::<JsValue>();
    let Some(data) = ingredient.manifest_data() else {
        return null;
    };
    let Ok(reader) = Reader::default().with_stream("c2pa", Cursor::new(data.as_ref())) else {
        return null;
    };
    match serde_json::from_str::<serde_json::Value>(&reader.json())
        .ok()
        .and_then(|value| neon_serde4::to_value(cx, &value).ok())
    {
        Some(value) => value,
        None => null,
    }
}
