Synthetic installation test package.
No artist provenance or scan result is asserted.
